/*
Defines HTTP endpoints related to pets.
Routes incoming requests to the corresponding controller functions.
*/

const express = require("express");
const petRouter = express.Router();
const {
  createPet,
  getAllPets,
  getPetsByOwner,
  getPetById,
  updatePet,
  deletePet,
  uploadPetPhoto,
} = require("../controllers/petController");
const { petImageUpload } = require("../utils/upload");
const verifyToken = require("../middleware/auth");

// Create a new pet
petRouter.post("/", createPet); //dev only
// petRouter.post("/", verifyToken, createPet);

// Get all pets for the authenticated user
petRouter.get("/", getAllPets); //dev only
// petRouter.get("/", verifyToken, getAllPets);

// Get pets by owner ID
petRouter.get("/owner/:ownerId", getPetsByOwner); //dev only
// petRouter.get("/owner/:ownerId", verifyToken, getPetsByOwner);

// Get a specific pet by ID
petRouter.get("/:id", getPetById); //dev only
// petRouter.get("/:id", verifyToken, getPetById);

// Update a pet
petRouter.put("/:id", updatePet); //dev only
// petRouter.put("/:id", verifyToken, updatePet);

// Delete a pet
petRouter.delete("/:id", deletePet); //dev only
// petRouter.delete("/:id", verifyToken, deletePet);

// Upload pet photo
petRouter.post("/upload-photo", petImageUpload, uploadPetPhoto);

module.exports = petRouter;
